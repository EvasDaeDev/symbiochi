// Arena simulation: orbital physics + contact damage + honor.

import { cellPx } from './arena_render.js';

export const ARENA_DEFAULTS = {
sunG: 3800,
bodyG: 900,
spaceDrag: 0.002,
contactDrag: 0.04,
kDamage: 0.22,
v0: 60,
speedCap: 2.0,
  minBlocksKO: 20,
  honorWin: 100,
  honorDamage: 0.06,
};

export function initMatch(arena){
  arena.mode = 'match';
  arena.resultText = '';
  arena.time.t = 0;

  const cx = arena.worldW/2;
  const cy = arena.worldH/2;
  // Sun in CELL units
  arena.sun = { x: cx, y: cy };

  const A = arena.fighters[0];
  const B = arena.fighters[1];

  // Starting orbits
  const rA = 180;
  const rB = 220;

  // Positions are in CELL units
  A.transform.pos = { x: cx - rA, y: cy };
  B.transform.pos = { x: cx + rB, y: cy };

  // Velocity perpendicular for orbit-ish motion
// === ORBITAL SPEED CALC ===
const dxA = A.transform.pos.x - cx;
const dyA = A.transform.pos.y - cy;
const rA2 = dxA*dxA + dyA*dyA;
const rA = Math.sqrt(rA2);

const dxB = B.transform.pos.x - cx;
const dyB = B.transform.pos.y - cy;
const rB2 = dxB*dxB + dyB*dyB;
const rB = Math.sqrt(rB2);

// v = sqrt(G / r)
const vA = Math.sqrt(arena.params.sunG / Math.max(1, rA));
const vB = Math.sqrt(arena.params.sunG / Math.max(1, rB));

// tangent vectors (perpendicular to radius)
A.transform.vel = {
  x: -dyA / rA * vA,
  y:  dxA / rA * vA
};

B.transform.vel = {
  x: -dyB / rB * vB,
  y:  dxB / rB * vB
};
  resetCombat(A);
  resetCombat(B);

  rebuildWorldCells(arena);
}

function orbitSpeedScale(mass){
  // small faster, big slower
  return clamp(1.15 - Math.log10(Math.max(10,mass))/4, 0.55, 1.15);
}

function resetCombat(f){
  f.alive = true;
  f.stats.damageDealt = 0;
  f.stats.damageTaken = 0;
  f.stats.contactFrames = 0;
  f.combat.grappleTimer = 0;
}

export function stepArena(arena, dt){
  if(arena.mode !== 'match') return;
  arena.time.t += dt;

  const A = arena.fighters[0];
  const B = arena.fighters[1];
  if(!A?.alive || !B?.alive){
    finish(arena);
    return;
  }

  // Physics
  applyForces(arena, A, B, dt);
  applyForces(arena, B, A, dt);

  // Integrate
  integrate(A, dt, arena);
  integrate(B, dt, arena);

  // Contact + damage
  const contact = detectContact(arena, A, B);
  if(contact.contactPairs > 0){
    resolveContact(arena, A, B, contact, dt);
  }

  // KO check
  if(A.mass <= arena.params.minBlocksKO){ A.alive = false; }
  if(B.mass <= arena.params.minBlocksKO){ B.alive = false; }

  if(!A.alive || !B.alive){
    finish(arena);
  }

  rebuildWorldCells(arena);
}

function applyForces(arena, self, other, dt){
  const p = self.transform.pos;
  const v = self.transform.vel;

  const toSunX = arena.sun.x - p.x;
  const toSunY = arena.sun.y - p.y;
  const r2s = toSunX*toSunX + toSunY*toSunY + 1200;
  const invRs = 1/Math.sqrt(r2s);
  const dirSx = toSunX * invRs;
  const dirSy = toSunY * invRs;

  // mutual gravity
  const toOx = other.transform.pos.x - p.x;
  const toOy = other.transform.pos.y - p.y;
  const r2o = toOx*toOx + toOy*toOy + 2400;
  const invRo = 1/Math.sqrt(r2o);
  const dirOx = toOx * invRo;
  const dirOy = toOy * invRo;

  // heavier attracts more, but acceleration divides by self.mass
  const accSun = arena.params.sunG / r2s;
  const accMut = arena.params.bodyG * (other.mass/Math.max(1,self.mass)) / r2o;

  v.x += (dirSx*accSun + dirOx*accMut) * dt;
  v.y += (dirSy*accSun + dirOy*accMut) * dt;

  // space drag
  v.x *= (1 - arena.params.spaceDrag);
  v.y *= (1 - arena.params.spaceDrag);
}

function integrate(f, dt, arena){
  const p = f.transform.pos;
  const v = f.transform.vel;

  // contact friction during grapple
  if(f.combat.grappleTimer > 0){
    v.x *= (1 - arena.params.contactDrag);
    v.y *= (1 - arena.params.contactDrag);
    f.combat.grappleTimer = Math.max(0, f.combat.grappleTimer - dt);
  }

  p.x += v.x * dt;
  p.y += v.y * dt;

  // clamp into view (CELL units)
  p.x = clamp(p.x, 10, arena.worldW-10);
  p.y = clamp(p.y, 10, arena.worldH-10);
}

function detectContact(arena, A, B){
  // quick circle check
  const dx = (A.transform.pos.x + A.geom.center.x) - (B.transform.pos.x + B.geom.center.x);
  const dy = (A.transform.pos.y + A.geom.center.y) - (B.transform.pos.y + B.geom.center.y);
  const d2 = dx*dx + dy*dy;
  const r = A.geom.radius + B.geom.radius + 6;
  if(d2 > r*r){
    return { contactPairs: 0, samples: null, normal: {x:0,y:0}, vIn:0 };
  }

  // cell-level contact using buckets for B
  const bucketSize = 8; // in cells
  const map = new Map();
  for(const c of B.geom.cells){
    const wx = Math.round(c.x + B.transform.pos.x);
    const wy = Math.round(c.y + B.transform.pos.y);
    const bx = Math.floor(wx / bucketSize);
    const by = Math.floor(wy / bucketSize);
    const key = bx+','+by;
    let arr = map.get(key);
    if(!arr){ arr=[]; map.set(key,arr); }
    arr.push([wx,wy,c]);
  }

  let pairs = 0;
  let nx=0, ny=0;
  for(const ca of A.geom.cells){
    const ax = Math.round(ca.x + A.transform.pos.x);
    const ay = Math.round(ca.y + A.transform.pos.y);
    const bx0 = Math.floor(ax / bucketSize);
    const by0 = Math.floor(ay / bucketSize);
    for(let dxB=-1; dxB<=1; dxB++){
      for(let dyB=-1; dyB<=1; dyB++){
        const arr = map.get((bx0+dxB)+','+(by0+dyB));
        if(!arr) continue;
        for(const [bx,by] of arr){
          const md = manhattan(ax,ay,bx,by);
          if(md === 0 || md === 1){
            pairs++;
            nx += (ax - bx);
            ny += (ay - by);
            break;
          }
        }
      }
    }
  }

  if(pairs === 0) return { contactPairs: 0, samples: null, normal:{x:0,y:0}, vIn:0 };

  // normal based on average direction A->B
  const inv = 1/Math.max(1, Math.hypot(nx,ny));
  const normal = { x: nx*inv, y: ny*inv };

  const rvx = A.transform.vel.x - B.transform.vel.x;
  const rvy = A.transform.vel.y - B.transform.vel.y;
  const vIn = Math.max(0, rvx*normal.x + rvy*normal.y);

  return { contactPairs: pairs, samples: null, normal, vIn };
}

function resolveContact(arena, A, B, contact, dt){
  A.stats.contactFrames++;
  B.stats.contactFrames++;


  const attackMultA = 1 + clamp(contact.vIn / arena.params.v0, 0, arena.params.speedCap);
  const attackMultB = 1 + clamp(contact.vIn / arena.params.v0, 0, arena.params.speedCap);

  // organ modifiers (simple v0.1): spikes add damage, shell reduces taken.
  const modA = getAttackMod(A) * getDefenseMod(B, contact.normal);
  const modB = getAttackMod(B) * getDefenseMod(A, {x:-contact.normal.x, y:-contact.normal.y});

  const dmgToB = Math.floor(contact.contactPairs * arena.params.kDamage * attackMultA * modA);
  const dmgToA = Math.floor(contact.contactPairs * arena.params.kDamage * attackMultB * modB);

  if(dmgToB>0) applyDamage(arena, B, dmgToB);
  if(dmgToA>0) applyDamage(arena, A, dmgToA);

  A.stats.damageDealt += dmgToB;
  B.stats.damageTaken += dmgToB;
  B.stats.damageDealt += dmgToA;
  A.stats.damageTaken += dmgToA;
  
  // === SLIDING RESOLUTION ===
const nx = contact.normal.x;
const ny = contact.normal.y;

const rvx = A.transform.vel.x - B.transform.vel.x;
const rvy = A.transform.vel.y - B.transform.vel.y;

const vn = rvx*nx + rvy*ny;

if(vn < 0){
  const impulse = vn * 0.5;

  A.transform.vel.x -= impulse * nx;
  A.transform.vel.y -= impulse * ny;

  B.transform.vel.x += impulse * nx;
  B.transform.vel.y += impulse * ny;
}
  
}

function getAttackMod(f){
  // if has spikes: +20%
  return f.geom.hasSpike ? 1.2 : 1.0;
}

function getDefenseMod(target, normal){
  // if has shell: reduce damage 25%
  return target.geom.hasShell ? 0.75 : 1.0;
}

function applyDamage(arena, target, dmg){
  // Remove cells closest to contact direction (approx): remove outermost along velocity.
  // v0.1: remove random perimeter-ish cells.
  const n = Math.min(dmg, target.geom.cells.length);
  if(n <= 0) return;

  // Simple: shuffle indices and remove
  for(let i=0;i<n;i++){
    const idx = (Math.random() * target.geom.cells.length) | 0;
    target.geom.cells.splice(idx,1);
  }

  target.mass = target.geom.cells.length;
  recomputeGeom(target.geom);
}

function finish(arena){
  arena.mode = 'finished';
  const A = arena.fighters[0];
  const B = arena.fighters[1];
  const winner = (A.alive && !B.alive) ? A : ((!A.alive && B.alive) ? B : null);

  if(!winner){
    arena.resultText = 'Draw';
    arena.winnerId = null;
    return;
  }
  arena.winnerId = winner.id;

  // Honor: win + damage
  const honorAdd = arena.params.honorWin + Math.round(winner.stats.damageDealt * arena.params.honorDamage);
  winner.meta.wins = (winner.meta.wins|0) + 1;
  winner.meta.honor = (winner.meta.honor|0) + honorAdd;

  arena.resultText = `${winner.name} wins (+${honorAdd} honor)`;
}

export function rebuildWorldCells(arena){
  const px = cellPx();
  for(const f of arena.fighters){
    if(!f) continue;
    if(!f.alive){ f.worldCells = []; continue; }
    const out=[];
    const ox = f.transform.pos.x;
    const oy = f.transform.pos.y;
    for(const c of f.geom.cells){
      // treat c.x/c.y as world-cell units
      const wx = Math.round(c.x + ox);
      const wy = Math.round(c.y + oy);
      out.push({
        px: wx * px,
        py: wy * px,
        type: c.type || c.t || c.kind || 'body'
      });
    }
    f.worldCells = out;
  }
}

export function recomputeGeom(geom){
  // bbox, center, radius, flags
  let minx=1e9, miny=1e9, maxx=-1e9, maxy=-1e9;
  let sx=0, sy=0;
  for(const c of geom.cells){
    if(c.x<minx) minx=c.x; if(c.y<miny) miny=c.y;
    if(c.x>maxx) maxx=c.x; if(c.y>maxy) maxy=c.y;
    sx += c.x; sy += c.y;
  }
  const n = Math.max(1, geom.cells.length);
  const cx = sx/n, cy = sy/n;
  let r=0;
  for(const c of geom.cells){
    const dx=c.x-cx, dy=c.y-cy;
    const d=Math.hypot(dx,dy);
    if(d>r) r=d;
  }
  geom.bbox = { minx, miny, maxx, maxy };
  geom.center = { x: cx, y: cy };
  geom.radius = r;
}

export function normalizeFromCapsule(organismState){
  // Convert a Symbiochi bud state into arena geom.
  const bodyCells = organismState?.body?.cells || organismState?.body?.blocks || [];
  const cells = [];
  for(const c of bodyCells){
    if(c && Number.isFinite(c.x) && Number.isFinite(c.y)){
      cells.push({ x: c.x, y: c.y, type: 'body' });
    }
  }
  // minimal flags from modules
  const mods = Array.isArray(organismState?.modules) ? organismState.modules : [];
  let hasShell=false, hasSpike=false;
  for(const m of mods){
    const t = m?.type || m?.t;
    if(t === 'shell') hasShell=true;
    if(t === 'spike') hasSpike=true;
  }

  const geom = { cells, modules: mods, hasShell, hasSpike, bbox:null, center:{x:0,y:0}, radius:0 };
  recomputeGeom(geom);
  return geom;
}

function manhattan(ax,ay,bx,by){
  return Math.abs(ax-bx) + Math.abs(ay-by);
}
function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }
