// mods/budding.js

export const BUD = {
  minLen: 20,
  probMult: 1/3,
  weightMult: 1.5, // быстрее, чем раньше
  bigParentSize: 230,
  bigParentSuccessMult: 2,
};
