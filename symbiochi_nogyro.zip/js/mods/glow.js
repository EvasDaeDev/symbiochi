// mods/glow.js

export const CRYSTAL_GLOW = {
  maxPx: 5,
};
